codegenes.net

existing users:
name- admin
password- password

name- johny
password- yespapa

import the ecom_db.sql file in your database

place product images in the img/products folder
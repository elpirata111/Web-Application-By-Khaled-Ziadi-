<!-- footer -->
	<div class="row bg-dark justify-content-center mt-4 py-3">
		<footer class="text-white">All Rights Reserved 2020 | Online Clothing Shop</footer>
	</div>
</div>
<script src="<?php echo $server; ?>js/script.js"></script>
</body>
</html>